# amgopalp.github.io
Lab 1
